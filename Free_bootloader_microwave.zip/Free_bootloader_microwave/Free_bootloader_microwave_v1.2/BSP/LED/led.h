#ifndef __LED_H
#define __LED_H	 
#include "sys.h"
/***********************
��Ŀ����LED����ͷ�ļ�
************************/   

typedef GPIO_TypeDef*   gpioled;

typedef struct{
		gpioled port;
		uint16_t pin;
}led_d;

void LED_Init(led_d *led,gpioled port,uint16_t pin);//��ʼ��
void led_config(led_d *led);
void led_off(led_d *led);
void led_on(led_d *led);
#endif
